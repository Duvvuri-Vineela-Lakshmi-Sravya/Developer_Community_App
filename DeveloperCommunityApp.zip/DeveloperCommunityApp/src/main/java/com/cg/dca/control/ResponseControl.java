package com.cg.dca.control;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Scanner;

import com.cg.dca.entity.*;
import com.cg.dca.exceptions.UnknownResponseException;
import com.cg.dca.service.*;

public class ResponseControl implements IResponseControl
{
	IResponseService fes = new ResponseService();
	IAdminControl ac = new AdminControl();
	DeveloperControl dc = new DeveloperControl();
	public Response addResponse(Response response) 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Answer:");
		String answer=sc.nextLine();
		sc.next();
		int accuracy = ac.accuracy(answer);
		if(accuracy>2)
		{
			LocalDate respDate = LocalDate.now();
			LocalTime respTime = LocalTime.now();
			Developer d2=response.getDev();
			Feed f = response.getFeed();
			Response resp = new Response(answer,respDate, respTime, accuracy, d2,f);
			return fes.addResponse(resp);
		}
		else
		{
			System.out.println("The response given by you is blocked");
			Developer d = response.getDev();
			dc.statusUpdateDev(d);
		}
		return null;
	}

	public Response editResponse(Response response,String answer) throws UnknownResponseException
	{
		return fes.editResponse(response,answer);
	}
	
	public Response likesofResponse(int responseId) throws UnknownResponseException 
	{
		return fes.likeResponse(responseId);//reputation
	}

	public Response removingResponse(int responseId) throws UnknownResponseException
	{
		return fes.removeResponse(responseId);
	}
		
	public List<Response> getResponseByFeed(int feedId) throws UnknownResponseException
	{
		return fes.getResponseByFeed(feedId);
	}
	public List<Response> getResponseByDev(int devId) throws UnknownResponseException
	{
		return fes.getResponseByDeveloper(devId);
	}
	public Response getResponseById(int resId) throws UnknownResponseException
	{
		return fes.getResponseByResId(resId);
	}
}