
package com.cg.dca.service;

import java.util.List;

import com.cg.dca.entity.Developer;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownResponseException;

public interface IDeveloperService {

	Developer addDeveloper(Developer dev);
	
	Developer editDeveloper(Developer dev,int choice,String val);
	
	Developer statusUpdate(Developer dev);
	
	Developer getDeveloper(int devId) throws UnknownDeveloperException, UnknownResponseException ;//throws UnknownDeveloperException;
	
	List<Developer> getAllDevelopers(); // by admin
	
	Developer getDevById(String userId);
}
