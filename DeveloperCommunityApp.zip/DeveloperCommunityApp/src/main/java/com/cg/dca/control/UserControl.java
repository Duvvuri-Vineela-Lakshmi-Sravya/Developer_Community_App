package com.cg.dca.control;

import java.util.Scanner;

import com.cg.dca.entity.User;
import com.cg.dca.exceptions.UnknownUserException;
import com.cg.dca.service.IUserService;
import com.cg.dca.service.UserService;

public class UserControl implements IUserControl{
	
	IUserService service = new UserService();
	
	public User getLoginDetails() throws UnknownUserException
	{
		IUserService service = new UserService();
		Scanner sc =new Scanner(System.in);
		System.out.println("***Login***");
		System.out.println("Enter UserId: ");
		String userId = sc.next();                                                                                            
		System.out.println("Password: ");                      
		String password = sc.next();
		System.out.println("Role: ");
		String role = sc.next();
		User luser=new User(userId,password,role);
		return service.login(luser);
	}

	public User logoutUser(User user)
	{
		return service.logout(user);
	}
}

