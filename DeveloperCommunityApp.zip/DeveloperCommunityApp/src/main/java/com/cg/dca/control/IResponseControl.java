package com.cg.dca.control;

import java.util.List;

import com.cg.dca.entity.Response;
import com.cg.dca.exceptions.UnknownResponseException;

public interface IResponseControl {

	Response addResponse(Response response);
	Response editResponse(Response Response,String answer) throws UnknownResponseException;
	Response likesofResponse(int responseId) throws UnknownResponseException;
	Response removingResponse(int responseId) throws UnknownResponseException;
	List<Response> getResponseByFeed(int feedId) throws UnknownResponseException;
	 List<Response> getResponseByDev(int devId) throws UnknownResponseException;
	 Response getResponseById(int resId) throws UnknownResponseException;
	 
}