package com.cg.dca.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
@Entity
public class Admin {
	
	@Id
	@GeneratedValue
	private int adminId;
	private String adminName;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "Admin_userId")
	private User user;

	public Admin()
	{
		
	}
	public Admin(String adminName, User user) {
		super();
		this.adminName = adminName;
		this.user = user;
	}
	
	public int getAdminId() {
		return adminId;
	}
	public void setAdminId(int adminId) {
		this.adminId = adminId;
	}
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", adminName=" + adminName + ", user=" + user + "]";
	}
	
}
