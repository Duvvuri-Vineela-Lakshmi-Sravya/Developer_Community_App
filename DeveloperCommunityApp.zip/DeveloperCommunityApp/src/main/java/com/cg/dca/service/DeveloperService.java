package com.cg.dca.service;

import java.util.List;
import com.cg.dca.entity.Developer;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownResponseException;
import com.cg.dca.repository.*;

public class DeveloperService implements IDeveloperService
{
	IDeveloperRepository res = new DeveloperRepository();
	
	public Developer addDeveloper(Developer dev)
	{
		return res.saveDeveloper(dev);
	}


	public Developer editDeveloper(Developer dev,int choice,String val)
	{
		return res.updateDeveloper(dev,choice,val);
	}

	public Developer statusUpdate(Developer dev)
	{
		return res.statusUpdate(dev);
	}
	
	public Developer getDeveloper(int devId) throws UnknownDeveloperException, UnknownResponseException
	{
		return res.fetchDeveloper(devId);
	}

	public List<Developer> getAllDevelopers() 
	{
		return res.fetchAllDevelopers();
	}
	
	public Developer getDevById(String userId)
	{
		return res.fetchDevId(userId);
	}


	

}
