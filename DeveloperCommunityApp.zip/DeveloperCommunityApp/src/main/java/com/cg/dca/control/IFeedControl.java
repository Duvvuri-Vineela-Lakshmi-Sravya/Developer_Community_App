 package com.cg.dca.control;

import java.util.List;

import com.cg.dca.entity.Developer;
import com.cg.dca.entity.Feed;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownFeedException;
import com.cg.dca.exceptions.UnknownResponseException;

public interface IFeedControl {

	Feed likesofFeeds(int feedId);
	 Feed getFeeds(int feedId) throws UnknownFeedException;
	 List<Feed> getFeedByDev(int devId);
	 List<Feed> getFeedByKey(String keyword) ;
	 List<Feed> getFeedByTopic(String topic);
	 Feed getFeedOptions(Developer developer) throws UnknownFeedException;
	 void getFeedsByFilter() throws UnknownResponseException, UnknownDeveloperException, UnknownFeedException;
}
 