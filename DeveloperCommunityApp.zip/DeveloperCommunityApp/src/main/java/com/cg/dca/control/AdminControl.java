package com.cg.dca.control;

import java.util.List;
import java.util.Scanner;

import com.cg.dca.entity.Admin;
import com.cg.dca.entity.Developer;
import com.cg.dca.entity.User;
import com.cg.dca.exceptions.UnknownAdminException;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.service.AdminService;
import com.cg.dca.service.DeveloperService;
import com.cg.dca.service.IAdminService;
import com.cg.dca.service.IDeveloperService;

public class AdminControl implements IAdminControl 
{
	IDeveloperService s1 = new DeveloperService();
	IAdminService s = new AdminService();
	public Admin adminRegister()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your name");
		String name=sc.next();
		System.out.println("Enter your preferred userId:");
		String userId=sc.next();
		
		System.out.println("Create Password:");
		String pwd=sc.next();
		IAdminService approve=new AdminService();
		boolean approved=approve.verifyAdminDetails(name,userId,pwd);
		if(approved==true)
		{
			User adminUser=new User(userId,pwd,"admin");
			Admin admin=new Admin(name,adminUser);
			s.createAdmin(admin);
			return admin;
		}
	return null;
	}
	
	public Admin getAdminByUserId(String userId)
	{
		return s.getAdByUserId(userId);
	}

	public int accuracy(String answer) {
		// TODO Auto-generated method stub
		return s.accurate(answer);
	}

	public int relevance(String query) {
		// TODO Auto-generated method stub
		return s.relevance(query);
	}

}

