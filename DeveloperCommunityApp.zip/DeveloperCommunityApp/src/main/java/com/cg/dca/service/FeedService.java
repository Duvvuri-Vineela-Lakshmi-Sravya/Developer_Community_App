package com.cg.dca.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.dca.entity.Feed;
import com.cg.dca.exceptions.UnknownFeedException;
import com.cg.dca.repository.FeedRepository;
import com.cg.dca.repository.IFeedRepository;

public class FeedService implements IFeedService{
	IFeedRepository re=new FeedRepository();

	public Feed addFeed(Feed feed) {
		
		return re.saveFeed(feed);
	}

	
	public Feed editFeed(Feed feed,String query) throws UnknownFeedException {
		
		return re.updateFeed(feed,query);
	}

	
	public Feed likeFeed(int feedId) {
		
		return re.likeFeed(feedId);
	}

	
	public Feed getFeed(int feedId) throws UnknownFeedException  {
		
		return re.fetchFeed(feedId);
	}


	public Feed removeFeed(int feedId) throws UnknownFeedException  {
		
		return re.deleteFeed(feedId);
	}

	
	public List<Feed> getFeedsByDeveloper(int devId) {

		return re.fetchFeedsByDeveloper(devId);
	}

	public List<Feed> getFeedsByTopic(String topic) {
		
		List<Feed> valid = new ArrayList<Feed>();
		List<Feed> li = re.fetchAllFeeds();
		for(Feed f: li)
		{
			String s =f.getTopic();
			if(s.contains(topic))
			{
				valid.add(f);
			}
		}
		return valid;
	}
	
	public List<Feed> getFeedsByKeyword(String keyword)
	{
		List<Feed> valid = new ArrayList<Feed>();
		List<Feed> li = re.fetchAllFeeds();
		for(Feed f: li)
		{
			String s =f.getQuery();
			if(s.contains(keyword))
			{
				valid.add(f);
			}
		}
		return valid;
	}
}