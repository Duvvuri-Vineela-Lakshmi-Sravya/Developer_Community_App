package com.cg.dca.control;

import com.cg.dca.entity.User;
import com.cg.dca.exceptions.UnknownUserException;

	public interface IUserControl 
	{

		public User getLoginDetails() throws UnknownUserException;

		User logoutUser(User user);

	}
