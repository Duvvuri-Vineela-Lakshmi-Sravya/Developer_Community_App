package com.cg.dca.control;

import java.util.List;

import com.cg.dca.entity.Developer;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownResponseException;

public interface IDeveloperControl
{
	 Developer developerRegister();

	Developer changeDeveloper(Developer developer);
	
	Developer statusUpdateDev(Developer d);
	
	Developer getDeveloperById(int devId) throws UnknownDeveloperException, UnknownResponseException;
	
	List<Developer> alldevelopDetails();

	Developer getDeveloperIdByUserId(String userId);
}
