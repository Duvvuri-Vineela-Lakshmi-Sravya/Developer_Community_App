package com.cg.dca.ui;

import java.util.*;
import com.cg.dca.service.*;
import com.cg.dca.control.AdminControl;
import com.cg.dca.control.DeveloperControl;
import com.cg.dca.control.FeedControl;
import com.cg.dca.control.IAdminControl;
import com.cg.dca.control.IDeveloperControl;
import com.cg.dca.control.IFeedControl;
import com.cg.dca.control.IResponseControl;
import com.cg.dca.control.IUserControl;
import com.cg.dca.control.ResponseControl;
import com.cg.dca.control.UserControl;
import com.cg.dca.entity.*;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownFeedException;
import com.cg.dca.exceptions.UnknownResponseException;
import com.cg.dca.exceptions.UnknownUserException;
public class UserInterface
{
public static void main(String args[]) throws UnknownUserException, UnknownResponseException, UnknownFeedException, UnknownDeveloperException
{
	Scanner sc = new Scanner(System.in);
	
	IUserControl uControl = new UserControl();
	IAdminControl aControl=new AdminControl();
	IDeveloperControl dControl=new DeveloperControl();
	IFeedControl fControl=new FeedControl();
	IResponseControl rControl=new ResponseControl();
	
	System.out.println("******WELCOME TO COMMUNITY DEVELOPER APP********");
	System.out.println();
	while(true)
	{
		System.out.println("1. Register");
		System.out.println("2. Login");
		System.out.println("3. EXIT");
		System.out.println("Enter your choice:");
		int choice = sc.nextInt();
		switch(choice)
		{
			case 1: System.out.println("***Register*****");
			System.out.println("Choose your role (admin/developer)?");
			String registerRole=sc.next();
			
			
			
			
			//Registration for admin
			
			if(registerRole.equalsIgnoreCase("admin"))
			{
				Admin admin=aControl.adminRegister();
				if(admin==null)
				{
					System.out.println("Registration Failed. Please try again.");
				}
				else
				{
					System.out.println("You have successfully registerd for the admin role with the following details");
					System.out.println(admin);
					System.out.println("Your unique adminId generated is "+admin.getAdminId());
					System.out.println(admin.getUser().getUserId()+" has successfully logged in.");
					int aLoginChoice=0;
					do 
					{
						System.out.println("1. Details of the developer by Id");
						System.out.println("2. Details of All Developers");
						System.out.println("3. LOGOUT");
						System.out.println("Enter your choice:");
						aLoginChoice=sc.nextInt();
						switch(aLoginChoice)
						{
							case 1:  System.out.println("Enter the developer-Id:");//aControl.adminservice1  or fControl or rControl
									int id = sc.nextInt();
									try
									{
										Developer dev =dControl.getDeveloperById(id);
										System.out.println(dev);
									}
									catch(UnknownDeveloperException e)
									{
										System.out.println(e.getMessage());
									}
									break;
							case 2:  List<Developer> li = new ArrayList<Developer>();  
									 li=dControl.alldevelopDetails(); 
									 for(Developer d: li)
									 {
										 System.out.println(d);//aControl.adminservice2 or fControl or rControl
									 }
									 break;
							case 3: User aLoggedIn=uControl.logoutUser(admin.getUser());
							System.out.println(aLoggedIn.getUserId()+"has successfully logged out.");
							break;
							default: System.err.println("Invalid choice");
						}
					}while(aLoginChoice!=3);
				}
			}
			
			
			//Registration for Developer
			
			else if(registerRole.equalsIgnoreCase("developer"))
			{
				Developer developer=dControl.developerRegister();
				if(developer==null)
				{
					System.out.println("Registration Unsuccessful. Please try again....");
				}
				else
				{
				System.out.println("You have successfully registerd for the developer role with the following details");
				System.out.println(developer);
				System.out.println("Your unique developerId generated is "+developer.getDevId());
				System.out.println(developer.getUser().getUserId()+" has successfully logged in.");
				int dLoginChoice=0;
				do 
				{
					System.out.println("1. Update Profile");
					System.out.println("2. Search developer by Id");
					System.out.println("3. Get All developers");
					System.out.println("4. My Feeds");  //1. create feed  2. Edit Feed 3. update feed --> returns feed object
					System.out.println("5. View all Feeds");  // 1. byId   2. byKeyword  3. byTopic ---> Returns list of feed objects
					System.out.println("6. LOGOUT");            // create response, edit response remove response, like response
					System.out.println("Enter your choice:");                            
					
					dLoginChoice=sc.nextInt();
					switch(dLoginChoice)
					{
						case 1: Developer d1=dControl.changeDeveloper(developer);
								System.out.println(d1);// dControl.updateProfile  or fControl or rControl
								break;
						case 2:  System.out.println("Enter the developer-Id:");//aControl.adminservice1  or fControl or rControl
								 int devId = sc.nextInt();
								 try
								 {
									 Developer dev =dControl.getDeveloperById(devId);
									 System.out.println(dev);
								 }
								 catch(UnknownDeveloperException e)
								 {
									 System.out.println(e.getMessage());
								 }
								 break; //dControl.viewFeed    or fControl or rControl
						case 3:  List<Developer> li = new ArrayList<Developer>();  
						 		 li=dControl.alldevelopDetails(); 
						 		 for(Developer d: li)
						 		 {
						 			 System.out.println(d);//aControl.adminservice2 or fControl or rControl
						 		 }
						 		 break; //dControl.Response    or fControl or rControl
						 		 
						case 4: Feed feed=fControl.getFeedOptions(developer);
								System.out.println("Your feed:"+feed+" has been updated successfully with feedId: "+feed.getFeedId());
								break;
								
						case 5: fControl.getFeedsByFilter();
								break;
										
						case 6: User dloggedIn=uControl.logoutUser(developer.getUser());
						System.out.println(dloggedIn.getUserId()+"has successfully logged out.");
						break;
						
						default: System.err.println("Invalid choice");
					}
				}while(dLoginChoice!=6);
			}
			}
			else
			{
				System.err.println("Invalid role");
			}
			break;
			//Login
			case 2: User loginUser=uControl.getLoginDetails();
			if(loginUser==null)
			{
				System.out.println("Please enter correct details");
			}
			
			
			//login for developer
			
			else if(loginUser.getRole().equalsIgnoreCase("developer"))
			{
				int loginChoice=0;
	
				System.out.println(loginUser.getUserId()+" has successfully logged in.");
				Developer dobj=dControl.getDeveloperIdByUserId(loginUser.getUserId());
				do 
				{
					System.out.println("1. Update Profile");
					System.out.println("2. View Feeds");
					System.out.println("3. Give Responses");
					System.out.println("4. LOGOUT");
					System.out.println("Enter your choice:");
					loginChoice=sc.nextInt();
					switch(loginChoice)
					{
					case 1:
						Developer d1=dControl.changeDeveloper(dobj);
							//System.out.println(d1);// dControl.updateProfile  or fControl or rControl
					break;
			case 2:  System.out.println("Enter the developer-Id:");//aControl.adminservice1  or fControl or rControl
					 int devId = sc.nextInt();
					 try
					 {
						 Developer dev =dControl.getDeveloperById(devId);
						 System.out.println(dev);
					 }
					 catch(UnknownDeveloperException e)
					 {
						 System.out.println(e.getMessage());
					 }
					 break; //dControl.viewFeed    or fControl or rControl
			case 3:  List<Developer> li = new ArrayList<Developer>();  
			 		 li=dControl.alldevelopDetails(); 
			 		 for(Developer d: li)
			 		 {
			 			 System.out.println(d);//aControl.adminservice2 or fControl or rControl
			 		 }
			 		 break; //dControl.Response    or fControl or rControl
						case 4: User dLoggedOut=uControl.logoutUser(loginUser);
						System.out.println(dLoggedOut.getUserId()+"has successfully logged out.");
						break;
						default: System.err.println("Invalid choice");
					}
				}while(loginChoice!=4);
			}
			
			// Login for admin
			
			else if(loginUser.getRole().equalsIgnoreCase("admin"))//Login for admin
			{
				int loginCh=0;
				System.out.println(loginUser.getUserId()+" has successfully logged in.");
				do 
				{
					System.out.println("1. Details of the developer by Id");
					System.out.println("2. Details of All Developers");
					System.out.println("3. LOGOUT");
					System.out.println("Enter your choice:");
					loginCh=sc.nextInt();
					Admin adobj = aControl.getAdminByUserId(loginUser.getUserId());
					System.out.println(adobj);
					switch(loginCh)
					{
						case 1:  System.out.println("Enter the developer-Id:");//aControl.adminservice1  or fControl or rControl
						int id = sc.nextInt();
						try
						{
							Developer dev =dControl.getDeveloperById(id);
							System.out.println(dev);
						}
						catch(UnknownDeveloperException e)
						{
							System.out.println(e.getMessage());
						}
						break;
						case 2:  List<Developer> li = new ArrayList<Developer>();  
						 li=dControl.alldevelopDetails(); 
						 for(Developer d: li)
						 {
							 System.out.println(d);//aControl.adminservice2 or fControl or rControl
						 }
						 break;
						case 3: User aLoggedIn=uControl.logoutUser(adobj.getUser());
						System.out.println(aLoggedIn.getUserId()+"has successfully logged out.");
						break;
						default: System.err.println("Invalid choice");
					}
				}while(loginCh!=3);
			}
			else
				System.out.println("Invalid role");
			break;

			case 3: System.out.println("THANK YOU FOR USING THE APPLICATION.");
					System.exit(0);
			default: System.err.println("Invalid Choice");
			}
		}
	}
}