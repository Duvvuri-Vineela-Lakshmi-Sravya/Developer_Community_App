package com.cg.dca.control;

import java.util.List;

import com.cg.dca.entity.Admin;
import com.cg.dca.entity.Developer;
import com.cg.dca.exceptions.UnknownAdminException;
import com.cg.dca.exceptions.UnknownDeveloperException;

public interface IAdminControl 
{
	Admin adminRegister();

	Admin getAdminByUserId(String userId);

	int accuracy(String answer);

	int relevance(String query);

}
