package com.cg.dca.exceptions;

public class UnknownResponseException extends Exception
{
	public UnknownResponseException(String s)
	{
		super(s);
	}
}
