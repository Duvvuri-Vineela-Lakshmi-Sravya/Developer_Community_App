package com.cg.dca.exceptions;

public class UnknownDeveloperException extends Exception
{
	public UnknownDeveloperException(String s)
	{
		super(s);
	}
}
