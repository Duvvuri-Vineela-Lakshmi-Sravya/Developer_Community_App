package com.cg.dca.utility;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JpaUtility {

	static EntityManagerFactory factory = null;

	public static EntityManagerFactory getFactory() {

		if (factory == null) {
			factory = Persistence.createEntityManagerFactory("Dev_Com_App");
		}
		return factory;
	}
}
