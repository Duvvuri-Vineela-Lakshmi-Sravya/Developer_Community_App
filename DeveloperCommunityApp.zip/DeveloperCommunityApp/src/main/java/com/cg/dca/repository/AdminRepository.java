package com.cg.dca.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.cg.dca.entity.Admin;
import com.cg.dca.entity.Developer;
import com.cg.dca.exceptions.UnknownAdminException;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.utility.JpaUtility;

public class AdminRepository implements IAdminRepository 
{
	EntityManagerFactory factory =null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	public Admin addAdminDetails(Admin admin)
	{
		factory = JpaUtility.getFactory();
	    manager = factory.createEntityManager();
		 transaction = manager.getTransaction();
		transaction.begin();
		manager.persist(admin);
		transaction.commit();//to save the work
		return admin;
	}

	public Admin fetchAdId(String userId) 
	{
		factory = JpaUtility.getFactory();
	    manager = factory.createEntityManager();
	    String selectQuery = "select a from Admin a where a.Admin_userId =?1";
	    Query query =manager.createQuery(selectQuery);
	    query.setParameter(1, userId);
	    Admin ad =(Admin) query.getSingleResult();
		return ad;
	}
	

	
}
