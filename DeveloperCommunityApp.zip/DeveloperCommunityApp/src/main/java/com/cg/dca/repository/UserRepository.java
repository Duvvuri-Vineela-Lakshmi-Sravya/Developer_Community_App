package com.cg.dca.repository;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import com.cg.dca.entity.User;
import com.cg.dca.exceptions.UnknownUserException;
import com.cg.dca.utility.JpaUtility;

public class UserRepository implements IUserRepository{
	
	EntityManagerFactory factory=null;
	EntityManager manager=null;
	EntityTransaction transaction = null;

	public User login(User user) throws UnknownUserException{
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		String id=user.getUserId();
		User loginUser=manager.find(User.class,id);
		if(loginUser==null)
		{
			try {
			throw new UnknownUserException("Please enter correct details");
			}
			catch(UnknownUserException uue)
			{
				System.out.println(uue);
			}
		}
		else
		{
			String pwd=loginUser.getPassword();
			String role=loginUser.getRole();
			if(pwd.equals(user.getPassword()) && role.equalsIgnoreCase(user.getRole()))
				return user;
		}
		return null;
	}

	public User logout(User user) {
		return user;
	}

}
