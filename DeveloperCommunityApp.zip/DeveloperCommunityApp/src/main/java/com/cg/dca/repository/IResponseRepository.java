package com.cg.dca.repository;

import java.util.List;

import com.cg.dca.entity.Response;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownFeedException;
import com.cg.dca.exceptions.UnknownResponseException;

public interface IResponseRepository {

	Response saveResponse(Response response);
	
	Response updateResponse(Response response, String answer) throws UnknownResponseException;
	
	Response likeResponse(int responseId) throws UnknownResponseException;

	Response deleteResponse(int responseId) throws UnknownResponseException; 
	
	List<Response> fetchResponseByFeed(int devId)  throws UnknownResponseException;
	
	List<Response> fetchResponseByDeveloper(int devId) throws  UnknownResponseException;

	Response fetchResponseById(int resId);
	
}
