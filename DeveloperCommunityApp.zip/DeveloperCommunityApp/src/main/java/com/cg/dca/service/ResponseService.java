package com.cg.dca.service;

import java.util.List;
import com.cg.dca.entity.Response;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownResponseException;
import com.cg.dca.repository.ResponseRepository;
import com.cg.dca.repository.IResponseRepository;

public class ResponseService implements IResponseService
{
	IResponseRepository re=new ResponseRepository();

	public Response addResponse(Response response)
	{
			return re.saveResponse(response);
	}
	public Response editResponse(Response response,String answer) throws UnknownResponseException
	{
			return re.updateResponse(response,answer);
	}
	public Response likeResponse(int responseId) throws UnknownResponseException
	{
		return re.likeResponse(responseId);
	}
	public Response removeResponse(int ResponseId) throws UnknownResponseException  
	{
		return re.deleteResponse(ResponseId);
	}
	public List<Response> getResponseByFeed(int devId) throws UnknownResponseException
	{
		return re.fetchResponseByFeed(devId);
	}
	public List<Response> getResponseByDeveloper(int devId) throws UnknownResponseException {

		return re.fetchResponseByDeveloper(devId);
	}
	public Response getResponseByResId(int resId)
	{
		return re.fetchResponseById(resId);
	}
}
