package com.cg.dca.repository;

import java.util.List;

import com.cg.dca.entity.Feed;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownFeedException;

public interface IFeedRepository {

	Feed saveFeed(Feed feed);
	 
	Feed likeFeed(int feedId);// throws UnknownFeedException;
	
	Feed fetchFeed(int feedId) throws UnknownFeedException;// throws UnknownFeedException;
	
	Feed deleteFeed(int feedId) throws UnknownFeedException; //throws UnknownFeedException;
	
	List<Feed> fetchFeedsByDeveloper(int devId);// throws UnknownDeveloperException;
	
	Feed updateFeed(Feed feed, String query) throws UnknownFeedException;
	
	List<Feed> fetchAllFeeds();
}