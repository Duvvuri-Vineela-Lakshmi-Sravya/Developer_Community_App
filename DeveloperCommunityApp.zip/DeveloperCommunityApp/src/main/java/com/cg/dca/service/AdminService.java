
package com.cg.dca.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.cg.dca.entity.Admin;
import com.cg.dca.entity.Developer;
import com.cg.dca.exceptions.UnknownAdminException;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.repository.AdminRepository;
import com.cg.dca.repository.IAdminRepository;

public class AdminService implements IAdminService
{

	IAdminRepository adres = new AdminRepository();
	public boolean verifyDevDetails(String name, String email, String skill, String userId, String pwd)
	{
		
		String validEmail= "^[\\w-\\.+]*[\\w-\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";  // abc@gmail.com == valid
		boolean validateEmail=email.matches(validEmail);
		if(validateEmail)// abcgmail@.com === invalid
		{
			System.out.println("Valid Email");
		}
		else
		{
			System.out.println("Invalid");
		}
		
		String validPwd= "^[^ ]{6,}$"; // special character, cap letter, small letters and numbers
		boolean validatePassword=pwd.matches(validPwd);
		if(validatePassword)// abcgmail@.com === invalid
		{
			System.out.println("Valid Password");
		}
		else
		{
			System.out.println("Invalid");
		}
		
		boolean validateSkill=false;
		if(skill.equalsIgnoreCase("beginner") || skill.equalsIgnoreCase("Intermediate") || skill.equalsIgnoreCase("advanced"))
		{
		validateSkill=true;
		}
		if(validateSkill)// abcgmail@.com === invalid
		{
			System.out.println("Valid Skill");
		}
		else
		{
			System.out.println("Invalid");
		}
	
		String validUserId= "^[A-Za-z]\\w{5,29}$"; // spaces are not allowed
		boolean validateUserId=userId.matches(validUserId);
		if(validateUserId)// abcgmail@.com === invalid
		{
			System.out.println("Valid User-id");
		}
		else
		{
			System.out.println("Invalid");
		}
		
		String validName="[A-Z]{1}[a-zA-Z]+(\\s{0,1}[A-Za-z])*";
		boolean validateName=name.matches(validName);
		if(validateName)// abcgmail@.com === invalid
		{
			System.out.println("Valid Name");
		}
		else
		{
			System.out.println("Invalid");
		}
		
		if(validateEmail && validateSkill && validatePassword && validateUserId && validateName)
			return true;
		return false;
	}

	public boolean verifyAdminDetails(String name, String userId, String pwd)
	{
		String validUserId= "^[A-Za-z]\\w{5,29}$";
		boolean validateUserId=userId.matches(validUserId);

		String validPwd= "^[^ ]{6,}$";// special character, cap letter, small letters and numbers
		boolean validatePassword=pwd.matches(validPwd);
		
		String validName="[A-Z]{1}[a-zA-Z]+(\\s{0,1}[A-Za-z])*";
		boolean validateName=name.matches(validName);
		
		if(validateUserId && validatePassword && validateName)
			return true;
		return false;
	}
	public Admin createAdmin(Admin admin)
	{
		// TODO Auto-generated method stub
		return adres.addAdminDetails(admin);
	}

	public Admin getAdByUserId(String userId) {
		// TODO Auto-generated method stub
		return adres.fetchAdId(userId);
	}

	public int accurate(String answer) {    // to delete 
		// TODO Auto-generated method stub
		/*String[] ans = answer.split(" ");
		List<String> li = new ArrayList<String>();
		li = Arrays.asList(ans);*/
		int accuracy=(int) Math.random();
		return accuracy;
	}

	public int relevance(String query) {
		int relevance=(int) Math.random();
		return relevance;
	}
	
	
	
}