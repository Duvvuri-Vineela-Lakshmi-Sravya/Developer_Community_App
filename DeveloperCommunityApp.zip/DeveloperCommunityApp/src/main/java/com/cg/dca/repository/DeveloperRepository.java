package com.cg.dca.repository;

import java.util.List;
import java.util.Scanner;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import com.cg.dca.entity.*;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.utility.JpaUtility;


public class DeveloperRepository implements IDeveloperRepository
{
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	public User user ;
	public Developer saveDeveloper(Developer dev)
	{
		factory = JpaUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		manager.persist(dev);
		transaction.commit();//to save the work
		return dev;
	}

	public Developer updateDeveloper(Developer dev,int choice,String val)
	{
		boolean validate = false;// just for removing errors in the code
		Scanner sc = new Scanner(System.in);
		factory = JpaUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		int id = dev.getDevId();
		Developer d = manager.find(Developer.class, id);
		transaction.begin();
		if(d==null)
		{
			System.out.println("Developer not found");
		}
		else
		{
			switch(choice)
			{
				case 1:	
						d.setName(val);
						transaction.commit();
						break;
				case 2: transaction.begin();
						d.setEmail(val);
						transaction.commit();
						break;
				case 3:transaction.begin();
						d.getUser().setPassword(val);
						transaction.commit();
						break;
			}
		}
		return d;
		}
	public Developer statusUpdate(Developer dev) 
	{
		factory = JpaUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		// change the status of the person whether he is blocked or not
		if(dev.isBlocked()==true)
		{
			transaction.begin();
			dev.setBlocked(false);
			transaction.commit();
		}
		else if(dev.isBlocked()==false)
		{
			transaction.begin();
			dev.setBlocked(true);
			transaction.commit();
		}
		
		return dev;
	}

	public Developer fetchDeveloper(int devId)  //Exception to be handled 
	{
		factory = JpaUtility.getFactory();
		manager = factory.createEntityManager();
		Developer dev = manager.find(Developer.class, devId);
		if (dev == null) {
			//throw new UnknownDeveloperException("Developer with "+devId+" is not found!");
		}
		return dev;
	}
		
	public List<Developer> fetchAllDevelopers() { // admin
		factory = JpaUtility.getFactory();
		manager = factory.createEntityManager();
		String selectquery ="Select d from Developer d";
		Query query= manager.createQuery(selectquery);
		  List<Developer> li = query.getResultList();
		  return li;
	}
	
	public Developer fetchDevId(String userId)
	{
		factory = JpaUtility.getFactory();
	    manager = factory.createEntityManager();
	    String selectquery ="Select d from Developer d where d.getUser().getUserId()=?1";
	    Query query= manager.createQuery(selectquery);
	    query.setParameter(1, userId);
	    Developer dev = (Developer) query.getSingleResult();
		return dev;
	}
}
