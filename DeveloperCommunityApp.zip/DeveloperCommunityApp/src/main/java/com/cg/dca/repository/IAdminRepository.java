package com.cg.dca.repository;

import java.util.List;

import com.cg.dca.entity.Admin;
import com.cg.dca.entity.Developer;
import com.cg.dca.exceptions.UnknownAdminException;
import com.cg.dca.exceptions.UnknownDeveloperException;

public interface IAdminRepository
{
	public Admin addAdminDetails(Admin admin);
	
	public Admin fetchAdId(String userId) ;
	
}
