package com.cg.dca.control;

import java.text.*;
import java.util.*;

import com.cg.dca.entity.*;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownResponseException;
import com.cg.dca.service.*;

public class DeveloperControl implements IDeveloperControl
{
	Scanner sc = new Scanner(System.in);
	IDeveloperService dev = new DeveloperService();
	public Developer developerRegister()
	{
		IAdminService approve = new AdminService();
		IDeveloperService dev = new DeveloperService();
		System.out.println("Enter your name");
		String name=sc.next();
		System.out.println("Enter your email ID");
		String email=sc.next();
		System.out.println("Enter your Skill level (Beginner/Intermediate/Advanced):");
		String skill=sc.next();
		System.out.println("Enter your preferred userId:");
		String userId=sc.next();
		System.out.println("Create Password:");
		String pwd=sc.next();
		
		boolean approved=approve.verifyDevDetails(name,email,skill,userId,pwd);
		if(approved==true)
		{
			List<Feed> li = new ArrayList<Feed>();
			boolean isVerified=true;
			boolean isBlocked=false;
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		    Date dateobj = new Date();
		    int totalFeeds = 0;
		    int reputation = 0;
		    String memberSince = df.format(dateobj);
			User devUser=new User(userId,pwd,"developer");
			Developer d = new Developer(name,email,skill,memberSince,li,devUser,totalFeeds,reputation,isVerified,isBlocked);
			dev.addDeveloper(d);
			return d;
		}
		return null;
	}
	
	public Developer changeDeveloper(Developer developer) 
	{
		int choice =0;
		do
		{
			System.out.println("******************PROFILE UPDATE******************");
			System.out.println("select any one option to update:");
			System.out.println("1.Name\n 2.Email\n 3.Password\n 4.Return back");
			System.out.println("Enter your choice:");
			choice = sc.nextInt();
			Developer d2 = null;
			switch(choice)
			{
			case 1: System.out.println("Enter your Name:");
					String name = sc.next(); 
					d2=dev.editDeveloper(developer,choice,name);
					break;
					
			case 2: System.out.println("Enter your Email Address:");
					String email = sc.next();
					d2=dev.editDeveloper(developer,choice,email);
					break;
			case 3: System.out.println("Enter new password:");
					String pass = sc.next();
					System.out.println("Re-enter password:");
					String pass1 = sc.next();
					if(pass.equals(pass1))
					{
						d2=dev.editDeveloper(developer,choice,pass);
					}
					else
					{
						System.out.println("Password doesnot match");
					}
			}
			return d2;
		}while(choice!=4);
	}
	public Developer getDeveloperById(int devId) throws UnknownDeveloperException, UnknownResponseException
	{
		return dev.getDeveloper(devId);
	}

	
	public List<Developer> alldevelopDetails() {
		return dev.getAllDevelopers();
	}

	public Developer getDeveloperIdByUserId(String userId) 
	{
		return dev.getDevById(userId);
	}

	public Developer statusUpdateDev(Developer d) {
		
		return dev.statusUpdate(d);
	}
}
