package com.cg.dca.exceptions;

public class UnknownAdminException extends Exception
{
	public UnknownAdminException(String s)
	{
		super(s);
	}
}
