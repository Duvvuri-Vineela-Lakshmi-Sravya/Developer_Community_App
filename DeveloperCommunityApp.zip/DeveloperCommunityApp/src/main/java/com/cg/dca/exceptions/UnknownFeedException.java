package com.cg.dca.exceptions;

public class UnknownFeedException extends Exception {
	public UnknownFeedException(String s)
	{
		super(s);
	}
}