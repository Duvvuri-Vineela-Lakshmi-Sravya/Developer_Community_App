package com.cg.dca.exceptions;

public class UnknownUserException extends Exception {

	public UnknownUserException(String s) 
	{
		super(s);
	}

}
