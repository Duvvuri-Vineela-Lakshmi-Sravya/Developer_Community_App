package com.cg.dca.control;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import com.cg.dca.entity.*;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownFeedException;
import com.cg.dca.exceptions.UnknownResponseException;
import com.cg.dca.service.*;
import com.cg.dca.utility.JpaUtility;


public class FeedControl implements IFeedControl {
	IFeedService fes = new FeedService();
	IAdminControl ac = new AdminControl();
	DeveloperControl dc = new DeveloperControl();
	Scanner sc = new Scanner(System.in);
	Feed f;
	public Feed getFeedOptions(Developer d) throws UnknownFeedException
	{
		int choice =0;
		do
		{
			System.out.println("1. New Feed");
			System.out.println("2.Edit Feed");
			System.out.println("3. Remove Feed");
			System.out.println("4.Return back");
			System.out.println("Enter your choice");
			choice = sc.nextInt();
			switch(choice) 
			{
				case 1:	System.out.println("Topic:");
						String topic = sc.nextLine();
						sc.next();
						System.out.println("Enter your Question:");
						String query = sc.nextLine();
						sc.next();
						int relevance = ac.relevance(query);
						if(relevance>0)
						{
							LocalDate feedDate = LocalDate.now();
							LocalTime feedTime = LocalTime.now();
							int totalComments=0;
							List<Response> li = new ArrayList<Response>();
							Feed f1=new Feed(query, feedDate,feedTime,topic, relevance, d,li, totalComments);
							f =fes.addFeed(f1);
							List<Feed> li2 = d.getFeeds();
							li2.add(f);
							return f;
						}
						else
						{
							System.out.println("Your query has been blocked");
							dc.statusUpdateDev(d);
						}
						break;
				case 2: System.out.println("Enter feedId:");
				         int id = sc.nextInt(); 
						 Feed feed = fes.getFeed(id);
						 System.out.println("Enter the updated Query:");
						String query1 = sc.nextLine();
						sc.next();
						f= fes.editFeed(feed,query1);
						return f;
				case 3: System.out.println("Enter feedId:");
	    	   			int id1 = sc.nextInt();
	    	   			f= fes.removeFeed(id1);
	    	   			return f;
			}
			return f;
		}while(choice!=4);

	}

	public void getFeedsByFilter() throws UnknownResponseException, UnknownDeveloperException, UnknownFeedException {
		IResponseControl res=new ResponseControl();
		IAdminControl ac=new AdminControl();
		IDeveloperService ds=new DeveloperService();
		IFeedService fs=new FeedService();
		Scanner sc=new Scanner(System.in);
		
		int choice=0;
		System.out.println("1. Get all feeds by developerID");
		System.out.println("2. Get all feeds by Keyword (view only)");
		System.out.println("3. Get all feeds by Topic (view only)");
		System.out.println("4. Return back");
		System.out.println("Enter your choice:");
		choice=sc.nextInt();
		switch(choice)
		{
		case 1: System.out.println("Enter developerId:");
				int dId=sc.nextInt();
				List<Feed> l1=new ArrayList<Feed>();
				l1=fes.getFeedsByDeveloper(dId);
				for(Feed f: l1)
					System.out.println(f);
				System.out.println("1. create Response");
				System.out.println("2. Edit Response");
				System.out.println("3. Delete Response");
				System.out.println("Enter your choice:");
				int ch=sc.nextInt();
				switch(ch)
				{
				case 1: System.out.println("Enter the feedID for which you want to give response:");
						int fId=sc.nextInt();
						List<Response> resp=res.getResponseByFeed(fId);
						int flag=0;
						for(Response r:resp)
						{
							if(r.getDev().getDevId()==dId)
							{
								flag=1;
								System.out.println("You are not eligible to create response.");
								break;
							}									
						}
						if(flag==0)
						{
							System.out.println("Enter your Answer: ");
							String answer=sc.nextLine();
							sc.next();
							LocalDate respDate = LocalDate.now();
							LocalTime respTime = LocalTime.now();
							int acc = ac.accuracy(answer); 
							Developer d1=ds.getDeveloper(dId);
							Feed f = fs.getFeed(fId);
							Response addResp = new Response(answer,respDate, respTime, acc, d1,f);
							System.out.println("Your Response "+res.addResponse(addResp)+" is successfully added.");
						}
						break;
				
				case 2: System.out.println("Enter the Response Id for which you want to edit:");
						int rId=sc.nextInt();
						Response r1=res.getResponseById(rId);
						
						System.out.println("Enter your answer:");
						String value=sc.nextLine();
						sc.next();
						if(r1==null)
						{
							try
							{
								throw new UnknownResponseException("Response is not available.");
							}
							catch(UnknownResponseException ure)
							{
								System.out.println(ure);
							}
						}
						System.out.println("Your Response "+res.editResponse(r1,value)+" is successfully updated.");		
						// remove comments for line 131.
						break;
						
				case 3: System.out.println("Enter the Response Id for which you want to edit:");
						int rId1=sc.nextInt();
						System.out.println("Your Response "+res.removingResponse(rId1)+" is successfully updated.");		
						break;
				}
			break;
			
			
		case 2: System.out.println("Enter keyword: ");
				String key=sc.next();
				List<Feed> l2=fs.getFeedsByKeyword(key);
				for(Feed f: l2)
					System.out.println(f);
				break;
		
		case 3: System.out.println("Enter Topic: ");
				String top=sc.next();
				List<Feed> l3=fs.getFeedsByTopic(top);
				for(Feed f: l3)
					System.out.println(f);
				break;
		}
		
	}
	
		public Feed likesofFeeds(int feedId) {
			
			return fes.likeFeed(feedId);
		}

	
		public Feed getFeeds(int feedId) throws UnknownFeedException {
			
			return fes.getFeed(feedId);
		}

		
		public List<Feed> getFeedByDev(int devId) {

			return fes.getFeedsByDeveloper(devId);
		}

		
		public List<Feed> getFeedByKey(String keyword) {
			
			return fes.getFeedsByKeyword(keyword);
		}

		
		public List<Feed> getFeedByTopic(String topic) {
			
			return fes.getFeedsByTopic(topic);
		}


		
	}