package com.cg.dca.service;

import java.util.List;

import com.cg.dca.entity.Admin;
import com.cg.dca.entity.Developer;
import com.cg.dca.exceptions.UnknownAdminException;
import com.cg.dca.exceptions.UnknownDeveloperException;

public interface IAdminService {

	boolean verifyDevDetails(String name, String email, String skill, String userId, String pwd);

	boolean verifyAdminDetails(String name, String userId, String pwd);
	
	Admin createAdmin(Admin admin);

	Admin getAdByUserId(String userId) ;

	int accurate(String answer);

	int relevance(String query);


}
