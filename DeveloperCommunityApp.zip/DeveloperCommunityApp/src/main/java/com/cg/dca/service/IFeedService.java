package com.cg.dca.service;

import java.util.List;

import com.cg.dca.entity.Feed;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownFeedException;

public interface IFeedService {

	Feed addFeed(Feed feed);//persist
	
	Feed editFeed(Feed feed,String query) throws UnknownFeedException;//update
	
	Feed likeFeed(int feedId);// throws UnknownFeedException;
	
	Feed getFeed(int feedId) throws UnknownFeedException;// throws UnknownFeedException;
	
	Feed removeFeed(int feedId) throws UnknownFeedException;
	
	List<Feed> getFeedsByDeveloper(int devId);// throws UnknownDeveloperException;
	
	List<Feed> getFeedsByKeyword(String keyword);
	
	List<Feed> getFeedsByTopic(String topic);
}