package com.cg.dca.service;

import com.cg.dca.entity.User;
import com.cg.dca.exceptions.UnknownUserException;
import com.cg.dca.repository.IUserRepository;
import com.cg.dca.repository.UserRepository;

public class UserService implements IUserService {
	
	IUserRepository userRep=new UserRepository();

	public User login(User user) throws UnknownUserException
	{
		return userRep.login(user);
	}

	public User logout(User user)
	{
		return userRep.logout(user);
	}

}
