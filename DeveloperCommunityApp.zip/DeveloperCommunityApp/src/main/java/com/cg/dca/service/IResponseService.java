package com.cg.dca.service;

import java.util.List;

import com.cg.dca.entity.Response;
import com.cg.dca.exceptions.UnknownDeveloperException;
import com.cg.dca.exceptions.UnknownFeedException;
import com.cg.dca.exceptions.UnknownResponseException;

public interface IResponseService {
	
	Response addResponse(Response resp);
	
	Response editResponse(Response resp, String answer) throws UnknownResponseException;
	
	Response removeResponse(int respId) throws UnknownResponseException;
	
	Response likeResponse(int respId) throws UnknownResponseException;
	
	List<Response> getResponseByFeed(int feedId) throws UnknownResponseException;
	
	List<Response> getResponseByDeveloper(int devId) throws UnknownResponseException;

	Response getResponseByResId(int resId);
}
