package com.cg.dca.repository;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import com.cg.dca.entity.Response;
import com.cg.dca.exceptions.UnknownResponseException;
import com.cg.dca.utility.JpaUtility;

public class ResponseRepository implements IResponseRepository {
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	public Response saveResponse(Response response) {
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		transaction.begin();
		manager.persist(response);
		transaction.commit();
		return response; 
		
	}
	
	//UPDATING THE RESPONSE DETAILS
	public Response updateResponse(Response response,String answer) throws UnknownResponseException {
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		int id=response.getRespId();
		Response f1=manager.find(Response.class, id);
		transaction.begin();
		f1.setAnswer(answer);
		transaction.commit();
		return f1;
	}

	public Response likeResponse(int responseId)
	{
		Response f1=manager.find(Response.class, responseId);
		
		return f1;
	}

	//DELETING THE DETAILS OF RESPONSE
	public Response deleteResponse(int responseId)  throws UnknownResponseException  {
		
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		Response response=manager.find(Response.class, responseId);
		if(response==null)  {
		
			throw new UnknownResponseException("fetching details not possible");
		}
		
		transaction.begin();
		manager.remove(response);
		return response;
	}

	public List<Response> fetchResponseByFeed(int devId) throws UnknownResponseException {
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		Response response=manager.find(Response.class, devId);
		List<Response> li=new ArrayList<Response>();
		li.add(response);
		return li;
	}
	
	public List<Response> fetchResponseByDeveloper(int devId) throws UnknownResponseException {
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		Response response=manager.find(Response.class, devId);
		List<Response> li=new ArrayList<Response>();
		li.add(response);
		return li;
	}

	public Response fetchResponseById(int resId) {
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		Response response=manager.find(Response.class, resId);
		return response;
	}
}