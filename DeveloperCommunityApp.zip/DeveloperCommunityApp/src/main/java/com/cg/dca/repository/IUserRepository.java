package com.cg.dca.repository;

import com.cg.dca.entity.User;
import com.cg.dca.exceptions.UnknownUserException;

public interface IUserRepository  {
	
	User login(User user) throws UnknownUserException;
	
	User logout(User user);
}
