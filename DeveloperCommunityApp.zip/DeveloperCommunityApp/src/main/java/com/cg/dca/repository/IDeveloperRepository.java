package com.cg.dca.repository;

import java.util.List;

import com.cg.dca.entity.Developer;
import com.cg.dca.exceptions.UnknownDeveloperException;

public interface IDeveloperRepository  {

	Developer saveDeveloper(Developer dev);//RegisterationDetails
	
	Developer fetchDeveloper(int devId) throws UnknownDeveloperException; //throws UnknownDeveloperException;
	
	List<Developer> fetchAllDevelopers();

	Developer updateDeveloper(Developer dev, int choice, String val);

	Developer statusUpdate(Developer dev);

	Developer fetchDevId(String userId);
}
