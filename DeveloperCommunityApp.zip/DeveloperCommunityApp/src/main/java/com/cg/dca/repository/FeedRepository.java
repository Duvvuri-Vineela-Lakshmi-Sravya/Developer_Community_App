package com.cg.dca.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;

import com.cg.dca.entity.Developer;
import com.cg.dca.entity.Feed;
import com.cg.dca.entity.User;
import com.cg.dca.exceptions.UnknownFeedException;
import com.cg.dca.utility.JpaUtility;

public class FeedRepository implements IFeedRepository {
	private static final Feed Feed = null;
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	//SAVING THE FEED DETAILS

	public Feed saveFeed(Feed feed) {
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		transaction.begin();
		manager.persist(feed);
		transaction.commit();
		
		return feed; 
		
	}
	
	//UPDATING THE FEED DETAILS

	public Feed updateFeed(Feed feed,String query) throws UnknownFeedException {
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		int id=feed.getFeedId();
		Feed f1=manager.find(Feed.class, id);
		if(f1==null)  {
			
			throw new UnknownFeedException("fetching details not possible");
		}
		transaction.begin();
		f1.setQuery(query);
		transaction.commit();
		return f1;
	}


	public Feed likeFeed(int feedId) {
		
		return null;
	}

	//FETCHING THE DETAILS
	public Feed fetchFeed(int feedId)  throws UnknownFeedException  {
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		Feed feed=manager.find(Feed.class, feedId);
		if(feed==null)  {
		
			throw new UnknownFeedException("fetching details not possible");
		}
		
		return feed;
	}

	//DELETING THE DETAILS OF FEED
	public Feed deleteFeed(int feedId)  throws UnknownFeedException  {
		
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		Feed feed=manager.find(Feed.class, feedId);
		if(feed==null)  {
		
			throw new UnknownFeedException("fetching details not possible");
		}
		
		transaction.begin();
		manager.remove(feed);
		
		return feed;
	}

	public List<Feed> fetchFeedsByDeveloper(int devId) {
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		transaction=manager.getTransaction();
		Feed feed=manager.find(Feed.class, devId);
		List<Feed> li=new ArrayList<Feed>();
		li.add(feed);
		return li;
	}


	
	public List<Feed> fetchAllFeeds()
	{
		factory=JpaUtility.getFactory();
		manager=factory.createEntityManager();
		String selectquery ="Select f from Feed f";
		Query query= manager.createQuery(selectquery);
		  List<Feed> li = query.getResultList();
		  return li;
	}

}